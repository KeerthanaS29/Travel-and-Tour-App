package com.example.toursimapp.Models;

import org.junit.jupiter.api.Test;

class CategoryModelTest {

    @Test
    void getFirstImage() {

    }

    @org.junit.jupiter.api.Test
    void setFirstImage() {
    }

    @org.junit.jupiter.api.Test
    void getPlace_id() {
    }

    @org.junit.jupiter.api.Test
    void setPlace_id() {
    }

    @org.junit.jupiter.api.Test
    void getPlace_name() {
    }

    @org.junit.jupiter.api.Test
    void setPlace_name() {
    }

    @org.junit.jupiter.api.Test
    void getDescription() {
    }

    @org.junit.jupiter.api.Test
    void setDescription() {
    }

    @org.junit.jupiter.api.Test
    void getAttractions() {
    }

    @org.junit.jupiter.api.Test
    void setAttractions() {
    }

    @org.junit.jupiter.api.Test
    void getBest_time() {
    }

    @org.junit.jupiter.api.Test
    void setBest_time() {
    }

    @org.junit.jupiter.api.Test
    void getRate_place() {
    }

    @org.junit.jupiter.api.Test
    void setRate_place() {
    }

    @org.junit.jupiter.api.Test
    void getClimate() {
    }

    @org.junit.jupiter.api.Test
    void setClimate() {
    }

    @org.junit.jupiter.api.Test
    void getReach_method() {
    }

    @org.junit.jupiter.api.Test
    void setReach_method() {
    }

    @org.junit.jupiter.api.Test
    void getLongitude() {
    }

    @org.junit.jupiter.api.Test
    void setLongitude() {
    }

    @org.junit.jupiter.api.Test
    void getLatitude() {
    }

    @org.junit.jupiter.api.Test
    void setLatitude() {
    }

    @org.junit.jupiter.api.Test
    void getArray_images() {
    }

    @org.junit.jupiter.api.Test
    void setArray_images() {
    }

    @org.junit.jupiter.api.Test
    void getDb_name() {
    }

    @org.junit.jupiter.api.Test
    void setDb_name() {
    }
}